const { Verify } = require("../../libs/jwt");

const isAuth = (req, res, next) => {
  try {
    const {token} = req.cookies;

    console.log(token);
     if (!token) return res.redirect("/loginpage");


    //res.status(201).json({msg:"Invalid token"})
    const verify = Verify(token);

    req.userId = verify;

    next();
  } catch (error) {
    
    res.redirect("/loginpage");

    //res.status(403).json({msg:error.message})
  }
};

module.exports = isAuth;
