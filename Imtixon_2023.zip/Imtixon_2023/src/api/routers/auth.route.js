const {Router}=require('express')
const { func, AddInsert, Register, Login, loginSSR, registerSSR, succesSSR, getUsers, getSubscriptions, deleteUser, chargeUserSubscription, checkSubscription } = require('../controllers/auth.controller')
const isAuth = require('../middlewares/isAuth')
const { createSubscription } = require('../controllers/auth.controller')
const { createUser } = require('../controllers/auth.controller')
const { getUserById } = require('../controllers/auth.controller')
const { getSubscriptionById } = require('../controllers/auth.controller')
const { updateUserAccountBalance } = require('../controllers/auth.controller')
const { updateSubscription } = require('../controllers/auth.controller')
const { deleteSubscr } = require('../controllers/auth.controller')
const router=Router()

router.post("/auth/func",func)

router.post("/auth/add",isAuth,AddInsert)

router.post("/auth/register", Register)

router.post("/auth/login", Login)

router.get('/loginpage',loginSSR)

router.get('/registerpage',registerSSR)

router.get('/succes',succesSSR)

router.post('/seeUsers',isAuth,getUsers)

router.post('/createsubscr',isAuth,createSubscription)

router.post('/createuser',isAuth,createUser)

router.get('/getsubscr',isAuth,getSubscriptions)

router.get('/getUserById',isAuth,getUserById)

router.get('getSubscrById',isAuth,getSubscriptionById)

router.put('/upduser',isAuth,updateUserAccountBalance)

router.patch('/updsubscr',isAuth,updateSubscription)

router.delete('/deleteuser/:userId',isAuth,deleteUser)

router.delete('/subscr/:userId',isAuth,deleteSubscr)

router.put('/chargeUser',isAuth,chargeUserSubscription)

router.post('/checkSubscr',isAuth,checkSubscription)




module.exports=router