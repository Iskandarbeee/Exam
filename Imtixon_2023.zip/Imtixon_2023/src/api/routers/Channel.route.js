const {Router}=require('express')
const { Channel, validTransation } = require('../controllers/Channel.controller')
const isAuth = require('../middlewares/isAuth')

const router=Router()

router.post('/validate/Transaction',isAuth,Channel)
router.post('/transation',isAuth,validTransation)

module.exports=router