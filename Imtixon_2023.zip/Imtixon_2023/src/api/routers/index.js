const auth=require('../routers/auth.route')

const crudAdmin=require('../routers/CRUD.admin.route')

const Channel=require('../routers/Channel.route')

const admin=require('../routers/admin.route')

module.exports=[auth,crudAdmin,Channel,admin]