const { Sign } = require("../../libs/jwt")
const pg = require("../../libs/pg");
const { passHash, passCompare } = require("../../libs/bcrypt");

const getUsers = async (req,res)=>{
    try
      { 
        const seeUsers= await pg(`
        SELECT * FROM users;
      `);
    
        res.status(200).json({msg:'Success',allUser:seeUsers})
    
      }
    catch(err){
        res.status(402).json({message:`GetAllErr ${err.message}`});
    }
    
    }

    
const createSubscription=async(req,res)=> {
    try {
      const {name,duration,price}=req.body
      const newSubscription=await pg(`
      INSERT INTO subscriptions (name, duration, price)
      VALUES ($1, $2, $3)
      RETURNING *;
    `,
    name,
    duration, 
    price);
    res.status(201).json({msg:newSubscription})
  
    } catch (error) {
      res.status(201).json({message:error.message})
    }
  }


  const createUser=async(req,res)=>{
    try
        {
            const {username, email, password}=req.body
    
        await pg( `
        INSERT INTO users (username, email, password)
        VALUES ($1, $2, $3)
        RETURNING *`,
        username, 
        email,
        password);
    
        res.status(201).json({
            msg:'Yangi User yaratildi'
        })
    }
    catch(e){
        res.status(403).json({msg:"User yaratilmadi",err:e.message})
    }
    }


    // Get all subscriptoins

const getSubscriptions=async(req,res) =>{
    try {
      const seeSubscr= await pg(`
      SELECT * FROM subscriptions
    `);
    res.status(201).json({msg:"succes",allSubscr:seeSubscr})
    } catch (error) {
    res.status(403).json({message:error.message})
    }
  }
  
  
// Foydalanuvchini ID orqali olish
const getUserById=async(req,res)=> {

    try {
      const {userId}=req.params
      const  userById= await pg (`
      SELECT * FROM users WHERE id = $1;
    `,userId);
    res.status(201).json({msg:"Succes",data:userById})
    } catch (error) {
      res.status(403).json({message:error.message})
    }
  }

  
  // Obunani ID orqali olish
const getSubscriptionById=async(req,res)=> {
    try {
      const {userId}=req.query;
      const  subscrById= await pg (`
      SELECT * FROM subscriptions WHERE id = $1;
    `,userId);
    res.status(201).json({msg:"Succes",data:subscrById})
    } catch (error) {
      res.status(403).json({message:error.message})
    }
  }

  
// Update a user's account balance

const  updateUserAccountBalance=async(req,res)=> {
    try {
    
      const{accountBalance,userId}=req.body
        await pg(`
          UPDATE users
          SET account_balance = $1, updated_at = NOW()
          WHERE id = $2; `,
          accountBalance, 
          userId);
          
          res.status(201).json({msg:"Success Update"})
    } catch (e) {
        
        res.status(401).json({message:`UpdError ${e.message}`})
    }
       
    }
    

// Obuna ma'lumotlarini yangilash
const  updateSubscription=async()=> {
 
    try {
     const { name, duration, price, subscriptionId }=req.body;
     await pg( `
       UPDATE subscriptions
       SET name = $1, duration = $2, price = $3, updated_at = NOW()
       WHERE id = $4
       RETURNING *;
     `,
     name,
     duration, 
     price, 
     subscriptionId);
     res.status(200).json({msg:'Success'})
   }
   catch(err){
     res.status(401).json({message:err.message})
   }
   }


   // Delete a user

const  deleteUser=async(req,res)=> {   
 
  try {

    const{userId}=req.query

    await pg( `
      DELETE FROM users WHERE id = $1; `,
      userId)
    res.status(200).json({msg:"Success Delete user"})
  } catch (error) {

    res.status(403).json({message:`DelError ${error.message}`})    
  }
}
   
    // Delete a subscr

const  deleteSubscr=async(req,res)=> {   
  try {
    const{userId}=req.query

    await pg( `
      DELETE FROM subscriptions WHERE id = $1; `,
      userId)
    res.status(200).json({msg:"Success Delete subscr"})
  } catch (error) {

    res.status(403).json({message:`DelError ${error.message}`})    
  }
}


const func=async(req,res)=>{     
    const {password}=req.body
    const token= await Sign(password);
    console.log(token);

    res.cookie('token',token)
    res.end("success");

}


const AddInsert=async(req,res)=>{

    const {email,password,username}=req.body;
    console.log(email,password,username);
    const secretPass=await passHash(password)
await pg(`Insert into users(email,username,password) values($1,$2,$3)`,email,username,secretPass)
res.status(201).json({
    msg:"success"
})
}


const Register = async(req,res)=>{
try {
    const { email,username,password,account_balance,is_paid_member } = req.body;

    const findUser = await pg("select * from users where username = $1",username);

    if (findUser.length) {
        return res.status(403).json({message:'Username mavjud'})
       
    }
    else{   
    const hashPass = await passHash(password);
    const newUser = (await pg (`insert into users(username,password,email,account_balance,is_paid_member) values($1,$2,$3,$4,$5)`,username,hashPass,email,account_balance,is_paid_member))[0];
    
    // res.status(201).json({message:"succes register" ,data:newUser})
    
    res.redirect("/loginpage")
    }
    } catch (error) {
    res.status(400).json({message:error})
    }
    }


const Login = async(req,res) => {
try {
    
    const {username,password } = req.body;
    
    const findUser = (await pg("select * from users where username = $1",username))[0];
    
    if (!findUser) { 
        return res.redirect('/registerpage')
        // res.status(403).json({message:'Bunday foydalanuvchi mavjud emas.'})
    }
    const compare = await passCompare(password,findUser.password)
    if(!compare){
        return res.status(403).json({message:'Username yoki Password xato'})
    }
    const token = await Sign(findUser.id);
    res.cookie('token',token)
    
    // res.status(200).json({message:'Success'})
            res.redirect('/succes')
    // res.redirect("/loginpage")
} catch (error) {
res.redirect("/registerpage");
    // res.status(400).json({message:error})
}
}


    const loginSSR=async(req,res)=>{

        res.render('login')
 
    }


    const registerSSR=async(req,res)=>{
        res.render('register')
    }


    const succesSSR=async (req,res)=>{
        res.render('succes')
    }

    
// Obunani tekshirish
const  checkSubscription=async(req,res)=> {

  const {userId}=req.query;
try {
  await (`SELECT us.*, s.name, s.duration, s.price
          FROM user_subscriptions us
          INNER JOIN subscriptions s ON us.subscription_id = s.id
          WHERE us.user_id = $1 AND start_date <= NOW() AND (end_date IS NULL OR end_date >= NOW());`,userId)
  
res.status(201).json({message:"Success"})
} catch (err) {
 res.status(402).json({msg:err.message})
}
}

// Obunachilar hisobidan pul yechish
const chargeUserSubscription=async(req,res)=> {
  const {userId, amount}=req.body
  try {
  await pg(`UPDATE users
          SET account_balance = account_balance - $1
          WHERE id = $2 AND account_balance >= $1;`,userId, amount)
 res.status(401).json({message:"success"})
} catch (err) {
  res.status(401).json({Xatolik: 'Obunachilar hisobidan pul yechishda muammo yuz berdi.',error: err});
  
}
}

module.exports={
    func,
    AddInsert,
    Register,
    Login,
    loginSSR,
    registerSSR,
    succesSSR,
    getUsers,
    createSubscription,
    createUser,
    getSubscriptions,
    getUserById,
    getSubscriptionById,
    updateUserAccountBalance,
    updateSubscription,
    deleteUser,
    deleteSubscr,
    checkSubscription,
    chargeUserSubscription, 
    
}