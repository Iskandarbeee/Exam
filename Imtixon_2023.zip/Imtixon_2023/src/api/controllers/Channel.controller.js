const pg=require('../../libs/pg')

const Channel=async(req,res)=>{

        const { user_id, subscription_id } = req.body;
      
        try {
          // Fetch user account balance
          const userResult = await pg(`
          SELECT account_balance, is_paid_member FROM users WHERE id = $1`,user_id)
      
          if (userResult.rows.length === 0) {
            return res.status(404).json({ error: 'User not found' });
          }
      
          const { account_balance, is_paid_member } = userResult.rows[0];
      
          // Fetch subscription details
          
          const subscriptionResult = await pg(`
          SELECT price, duration FROM subscriptions WHERE id = $1`,subscription_id)
      
          if (subscriptionResult.rows.length === 0) {
            return res.status(404).json({ error: 'Subscription not found' });
          }
      
          const { price, duration } = subscriptionResult.rows[0];
      
          if (is_paid_member) {
            return res.status(400).json({ error: 'User is already a paid member' });
          }
      
          if (account_balance < price) {
            return res.status(400).json({ error: 'Insufficient account balance' });
          }
      
          // Perform the transaction
          const newBalance = account_balance - price;
          await pg (`UPDATE users SET account_balance = $1, is_paid_member = true WHERE id = $2`,newBalance, user_id)
          
      
          // Calculate start and end dates for the subscription
          const startDate = new Date();
          const endDate = new Date();
          endDate.setDate(endDate.getDate() + duration);
      
          // Insert a new record in the user_subscriptions table
            await pg(`INSERT INTO user_subscriptions (user_id, subscription_id, start_date, end_date) VALUES ($1, $2, $3, $4)`,user_id, subscription_id, startDate, endDate)      
          
            return res.json({ message: 'Transaction successful' });
        } catch (error) {
          console.error('Error validating transaction:', error);
          return res.status(500).json({ error: 'Internal server error' });
        }
      }

      
      const validTransation=async (req, res) => {
        try {
          const { user_id, transaction_amount } = req.body;
      
          // Get user's active subscriptions from the database
          const activeSubscriptions = await pg(
            `SELECT * FROM user_subscriptions
            WHERE user_id = $1
            AND start_date <= NOW()
            AND (end_date IS NULL OR end_date >= NOW())`,
            [user_id]
          );
      
          // Check if any active subscription covers the transaction amount
          let isValidTransaction = false;
          for (const subscription of activeSubscriptions.rows) {
            const subscriptionPrice = subscription.price;
            if (transaction_amount <= subscriptionPrice) {
              isValidTransaction = true;
              break;
            }
          }
      
          if (isValidTransaction) {
            return res.status(200).json({ message: 'Transaction is valid.' });
          } else {
            return res.status(403).json({ message: 'Transaction is not covered by any active subscription.' });
          }
        } catch (error) {
          console.error('Error while validating transaction:', error);
          return res.status(500).json({ message: 'Internal server error.' });
        }
      };
      




module.exports={
    Channel,
    validTransation,
}