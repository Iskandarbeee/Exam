const config=require('../config/index')
const express=require("express")
const cookie=require("cookie-parser")
const ejs=require('ejs')
const fileUpload=require('express-fileupload')
const router = require('./api/routers/auth.route')
const bodyPar=require("body-parser")
const app=express()
app.use(express.urlencoded({extended:true}));
app.use(express.json())
app.use(bodyPar.json())
app.use(cookie())

app.use(fileUpload())
app.use(router)

app.set('view engine','ejs')
app.set('views',process.cwd()+'/src/views')

app.use(express.static(process.cwd()+'/public'))
app.use(express.static(process.cwd()+'/src/'))




app.listen(config.port,()=>{
    console.log(`Serverimiz ${config.port}-portda ishlamoqda...`);
})